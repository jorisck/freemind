Welcome to Freemind.

A simple text editor to capture your raw ideas, on the fly.
No folders to create, no Save button: you write, it's saved.

Write however it comes. An idea, a list, a half-finished sentence.
It doesn't need to be clean. You sort it out later, or never.


At the bottom of the screen

18px: changes the text size
Random: tries a random font
Fullscreen: nothing but your text
New Entry: a new note
Image icon: changes the background (Paper, Image or Classic)
Moon: light or dark mode
Clock: opens the history


In the history

Search: find a note by any word in it.
Pin: keep a note at the top of the list.
Projects: group notes in a folder. The + next to Projects creates one.
Branches: copy a note to go in another direction without touching the original.

Right-click a note (or use the "…" on hover) for all of this.
Click History at the top to open the folder in Finder.


Your notes

They stay on your Mac, as plain text files any app can open.
Nothing is sent anywhere.


Based on Freewrite by Farza Majeed (MIT License).
